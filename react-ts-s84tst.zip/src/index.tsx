import React, { Component } from 'react';
import { render } from 'react-dom';
import { Rating } from 'semantic-ui-react';

interface MyCatalogItemProps{
  img: string;
  descricao?: string;
  oldvalue: string;
  newvalue: string;
  parcelamento?: string;
}

function MyCatalogItem(props: MyCatalogItemProps) {
  return(
    <div className="card">
      <div className="center aligned">
        <img src={props.img} />
      </div>
      <div className="content">
        <div className="description">
          {props.descricao}
        </div>
        <div className="extra">
          <Rating icon='star' defaultRating={3} maxRating={5} />
        </div>
      </div>
      <div className="extra content">
        <div style={{ textDecoration: 'line-through'}}>
          {props.oldvalue}
        </div>
        <div className="header">
          {props.newvalue}
        </div>
        <div className="">
          {props.parcelamento}
        </div>
      </div>
    </div>
  );
}

function MyCatalog() {
  return(
    <div className="ui link cards five stackable" >
      <MyCatalogItem 
        img="https://c.mlcdn.com.br//carga-para-aparelho-de-barbear-gillette-mach3-8-cartuchos/v/210x210/218044500.jpg" 
        descricao="Carga para Aparelho de Barbear Gillette Mach3 - 8 Cartuchos
" 
        oldvalue="de R$ 63,99" 
        newvalue="por R$37,90" 
        parcelamento="em 2x de R$ 18,95 sem juros" 
      />
      <MyCatalogItem 
        img="https://c.mlcdn.com.br//fone-de-ouvido-jbl-intra-auricular-com-microfone-preto-t110/v/210x210/218608200.jpg" 
        descricao="Fone de Ouvido JBL Intra-Auricular - com Microfone Preto T110
" 
        oldvalue="de R$ 59,00" 
        newvalue="por R$39,90" 
        parcelamento="" 
      />
      <MyCatalogItem 
        img="https://c.mlcdn.com.br//iphone-8-apple-64gb-cinza-espacial-4g-tela-4-7-retina-cam.-12mp-selfie-7mp-ios-11/v/210x210/155542600.jpg" 
        descricao="iPhone 8 Apple 64GB Cinza Espacial 4G Tela 4,7” - Retina Câm. 12MP + Selfie 7MP iOS 11
" 
        oldvalue="de R$ 3.999,00" 
        newvalue="por R$3.254,07à vista(7% de desconto)" 
        parcelamento="" 
      />
      <MyCatalogItem 
        img="https://c.mlcdn.com.br//jogo-de-potes-hermetico-electrolux-com-tampa-quadrado-80000565-10-pecas/v/210x210/212738100.jpg" 
        descricao="Jogo de Potes Hermético Electrolux com Tampa - Quadrado 80000565 10 Peças
" 
        oldvalue="de R$ 129,90" 
        newvalue="por R$69,90" 
        parcelamento="" 
      />  
    </div>
  );
}

function App () {  
  return (
    <div className="ui container"> 
      <MyCatalog />
    </div>
  );  
}

const container = document.querySelector('#root');
const app = <App />;

render(app, container);